--------------------------------------------------------
--  파일이 생성됨 - 수요일-12월-10-2025   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table 가게
--------------------------------------------------------

  CREATE TABLE "C##JYS"."가게" 
   (	"가게아이디" VARCHAR2(20 BYTE), 
	"점주아이디" VARCHAR2(20 BYTE), 
	"가게명" VARCHAR2(30 BYTE), 
	"주소" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table 메뉴
--------------------------------------------------------

  CREATE TABLE "C##JYS"."메뉴" 
   (	"메뉴아이디" VARCHAR2(20 BYTE), 
	"가게아이디" VARCHAR2(20 BYTE), 
	"메뉴명" VARCHAR2(20 BYTE), 
	"가격" NUMBER(*,0), 
	"설명" VARCHAR2(150 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table 배달회원
--------------------------------------------------------

  CREATE TABLE "C##JYS"."배달회원" 
   (	"회원아이디" VARCHAR2(20 BYTE), 
	"비밀번호" VARCHAR2(20 BYTE), 
	"이름" VARCHAR2(20 BYTE), 
	"연락처" VARCHAR2(20 BYTE), 
	"주소" VARCHAR2(100 BYTE), 
	"역할" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into C##JYS."가게"
SET DEFINE OFF;
Insert into C##JYS."가게" ("가게아이디","점주아이디","가게명","주소") values ('01','2','중곡분식','광진구중곡동');
Insert into C##JYS."가게" ("가게아이디","점주아이디","가게명","주소") values ('02','3','보광쌀국수','용산구보광동');
Insert into C##JYS."가게" ("가게아이디","점주아이디","가게명","주소") values ('03','5','잠실파스타','송파구잠실동');
Insert into C##JYS."가게" ("가게아이디","점주아이디","가게명","주소") values ('04','6','방배초밥','서초구방배동');
REM INSERTING into C##JYS."메뉴"
SET DEFINE OFF;
Insert into C##JYS."메뉴" ("메뉴아이디","가게아이디","메뉴명","가격","설명") values ('10','01','떡볶이',4500,null);
Insert into C##JYS."메뉴" ("메뉴아이디","가게아이디","메뉴명","가격","설명") values ('20','02','쌀국수',10000,'양지');
Insert into C##JYS."메뉴" ("메뉴아이디","가게아이디","메뉴명","가격","설명") values ('30','03','파스타',15000,'오일');
Insert into C##JYS."메뉴" ("메뉴아이디","가게아이디","메뉴명","가격","설명") values ('40','04','세트초밥',15000,'10피스');
REM INSERTING into C##JYS."배달회원"
SET DEFINE OFF;
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('1','1234','정영서','01082864493','서울광진구중곡동','고객');
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('2','1234','정쫑이','01012345678','서울광진구중곡동','점주');
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('3','1234','김인공','01098765432','서울용산구보광동','점주');
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('4','1234','이자바','01019283746','서울용산구이태원동','배달기사');
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('5','1234','박지능','01054678923','서울송파구잠실동','점주');
Insert into C##JYS."배달회원" ("회원아이디","비밀번호","이름","연락처","주소","역할") values ('6','1234','최소프트','01012378945','서울서초구방배동','점주');
--------------------------------------------------------
--  DDL for Index SYS_C008453
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JYS"."SYS_C008453" ON "C##JYS"."가게" ("가게아이디") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008460
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JYS"."SYS_C008460" ON "C##JYS"."메뉴" ("메뉴아이디") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008448
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JYS"."SYS_C008448" ON "C##JYS"."배달회원" ("회원아이디") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table 가게
--------------------------------------------------------

  ALTER TABLE "C##JYS"."가게" MODIFY ("가게아이디" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."가게" MODIFY ("점주아이디" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."가게" MODIFY ("가게명" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."가게" MODIFY ("주소" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."가게" ADD PRIMARY KEY ("가게아이디")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table 메뉴
--------------------------------------------------------

  ALTER TABLE "C##JYS"."메뉴" MODIFY ("메뉴아이디" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."메뉴" MODIFY ("가게아이디" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."메뉴" MODIFY ("메뉴명" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."메뉴" MODIFY ("가격" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."메뉴" ADD CHECK (가격 >= 0) ENABLE;
  ALTER TABLE "C##JYS"."메뉴" ADD PRIMARY KEY ("메뉴아이디")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table 배달회원
--------------------------------------------------------

  ALTER TABLE "C##JYS"."배달회원" MODIFY ("회원아이디" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."배달회원" MODIFY ("비밀번호" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."배달회원" MODIFY ("이름" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."배달회원" MODIFY ("역할" NOT NULL ENABLE);
  ALTER TABLE "C##JYS"."배달회원" ADD CHECK (역할 in ('고객', '점주', '배달기사')) ENABLE;
  ALTER TABLE "C##JYS"."배달회원" ADD PRIMARY KEY ("회원아이디")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table 가게
--------------------------------------------------------

  ALTER TABLE "C##JYS"."가게" ADD FOREIGN KEY ("점주아이디")
	  REFERENCES "C##JYS"."배달회원" ("회원아이디") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table 메뉴
--------------------------------------------------------

  ALTER TABLE "C##JYS"."메뉴" ADD FOREIGN KEY ("가게아이디")
	  REFERENCES "C##JYS"."가게" ("가게아이디") ENABLE;
